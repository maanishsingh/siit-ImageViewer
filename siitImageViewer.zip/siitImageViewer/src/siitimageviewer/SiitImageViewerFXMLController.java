/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package siitimageviewer;

import java.awt.Dimension;
import java.awt.Toolkit;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.net.URISyntaxException;
import java.net.URL;
import java.util.List;
import java.util.ResourceBundle;
import java.util.logging.Level;
import java.util.logging.Logger;
import javafx.beans.binding.Bindings;
import javafx.beans.property.DoubleProperty;
import javafx.beans.property.SimpleDoubleProperty;
import javafx.beans.value.ChangeListener;
import javafx.beans.value.ObservableValue;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.input.DragEvent;
import javafx.scene.input.MouseDragEvent;
import javafx.scene.input.TransferMode;
import javafx.scene.layout.BorderPane;
import javafx.stage.FileChooser;
import javafx.stage.FileChooser.ExtensionFilter;
import javafx.stage.Stage;
import javax.swing.text.ChangedCharSetException;

/**
 *
 * @author manish
 */
public class SiitImageViewerFXMLController implements Initializable {
    File path;
    List<File> ifiles;
    int sn=1;
     boolean pre=false;
     boolean next = false;
    @FXML
    public ImageView imgV;
    @FXML
    private Button btnPre;
    @FXML
    private Label lblStatus;
    @FXML
    private Button btnNext;
    @FXML
    private BorderPane borderPane;
 
    @Override
    public void initialize(URL url, ResourceBundle rb) {
       Dimension screenSize = Toolkit.getDefaultToolkit().getScreenSize();
        double sch = screenSize.height;
        double scw = screenSize.width;
        imgV.preserveRatioProperty();
        imgV.setFitHeight(sch-200);
        imgV.setFitWidth(scw);
        
       //ifiles.lastIndexOf(rb)
        
       
    }

    public void openImageFromPath(File f) throws FileNotFoundException{
     
        Image image = new Image(new FileInputStream(f));
        imgV.setImage(image);
       String s =new Long(f.length()/1000).toString();
        setNameAndSize(s,f.getName());
       // setRatio();
       //nextImage();
       
       
    }

    @FXML
    private void openImage(ActionEvent event) {
        FileChooser fc = new FileChooser();
        fc.getExtensionFilters().addAll(new ExtensionFilter("JPEG","*.jpeg"),
                new ExtensionFilter("PNG","*.png"),
                new ExtensionFilter("ICO","*.ico"),
                new ExtensionFilter("GIF","*.gif"));
        fc.setTitle("Open Image/Images");
        ifiles = fc.showOpenMultipleDialog(null);
        try {
            openImageFromPath(ifiles.get(0));
        } catch (FileNotFoundException ex) {
            Logger.getLogger(SiitImageViewerFXMLController.class.getName()).log(Level.SEVERE, null, ex);
        }
        
        
    }

    @FXML
    private void imgVDragOver(DragEvent event) {
        event.acceptTransferModes(TransferMode.ANY);      
    }

    @FXML
    private void imgVDragDone(DragEvent event) {
     ifiles=  event.getDragboard().getFiles();
     path = ifiles.get(0);
        try {
            openImageFromPath(path);
        } catch (FileNotFoundException ex) {
            Logger.getLogger(SiitImageViewerFXMLController.class.getName()).log(Level.SEVERE, null, ex);
        }
        if(ifiles.size()>1){
       sn=1;
       pre=false;
        }
    }
    
    private void setNameAndSize(String size,String name){
        lblStatus.setText("Size :"+size+" KB\t Name: "+name);
    }
     
     
    @FXML
    private void nextImage(ActionEvent event) throws FileNotFoundException{
        if(next){
            sn++;
            next=false;
        }
        if(ifiles != null && ifiles.size()>1){
            openImageFromPath(ifiles.get(sn));
            System.out.println("next image "+ sn);
            if(sn< ifiles.size())
              sn++;
            if(pre!=true)
                pre=true;
//  btnNext.disableProperty();
            
        }
                }
    @FXML private void preimage(ActionEvent event) throws FileNotFoundException{
        if(pre){
            sn--;
            pre=false;
        }
        if(next!=true)
            next=true;
        
        if(ifiles != null && sn<= ifiles.size()){
            openImageFromPath(ifiles.get(sn-1));
            System.out.println("pre image "+ sn);
            if(sn!=0)
                sn--;
        }
    }
    
    public void setRatio(){
        DoubleProperty width = imgV.fitWidthProperty();
        DoubleProperty height = imgV.fitHeightProperty();
        //System.out.println(height);
        
       width.bind(Bindings.selectDouble(imgV.sceneProperty(),"width"));
        height.bind(Bindings.selectDouble(imgV.sceneProperty(),"height"));
       
        
    }
    @FXML
    private void closeSystem(ActionEvent event){
        System.exit(0);
    }
    @FXML
    private void about(ActionEvent event) throws FileNotFoundException, URISyntaxException{
        //ClassLoader classLoader = getClass().getClassLoader();
        FileInputStream input = new FileInputStream("src/images/imageViewer.png");
        Image himage = new Image(input);
        imgV.setImage(himage);
        //File aimg = new File("imageViewer.png");
        //openImageFromPath(aimg);
    }
    
    
    
}
